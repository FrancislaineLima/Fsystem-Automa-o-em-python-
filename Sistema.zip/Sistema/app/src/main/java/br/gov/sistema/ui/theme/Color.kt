package br.gov.sistema.ui.theme

import androidx.compose.ui.graphics.Color

// Pastel Theme Colors from Image
val BackgroundPink = Color(0xFFFFEBF2)
val CardWhite = Color(0xFFFFFFFF)
val PrimaryPink = Color(0xFFFF4B81)
val SecondaryPink = Color(0xFFFF85A1)
val AccentPink = Color(0xFFFFD1DC)
val TextDark = Color(0xFF4A4A4A)
val GrayText = Color(0xFF9E9E9E)

// Default Compose Colors
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)