package br.gov.sistema

import android.content.Context
import android.os.Bundle
 import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.Label
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.Notes
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit
import br.gov.sistema.ui.theme.SistemaTheme
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

// 1. Modelos de Dados
data class Product(
    val code: String, val brand: String, val type: String,
    val category: String, val price: String, val cost: String, val obs: String
)

data class User(val name: String, val email: String, val pass: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SistemaTheme {
                AppPrincipal()
            }
        }
    }
}

// Persistência com SharedPreferences + Gson
object Database {
    private const val PREFS_NAME = "fsystem_prefs"
    private const val KEY_USERS = "usuarios"
    private const val PREFIX_PRODS = "produtos_"
    private val gson = Gson()

    fun saveUsers(context: Context, users: Map<String, User>) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit {
            putString(KEY_USERS, gson.toJson(users))
        }
    }

    fun loadUsers(context: Context): MutableMap<String, User> {
        val json = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_USERS, null)
        return if (json == null) {
            mutableMapOf("admin@fsystem.com" to User("Administrador", "admin@fsystem.com", "admin"))
        } else {
            val type = object : TypeToken<MutableMap<String, User>>() {}.type
            gson.fromJson(json, type)
        }
    }

    fun saveProducts(context: Context, email: String, products: List<Product>) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit {
            putString(PREFIX_PRODS + email.lowercase(), gson.toJson(products))
        }
    }

    fun loadProducts(context: Context, email: String): List<Product> {
        val json = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(PREFIX_PRODS + email.lowercase(), null)
        return if (json == null) emptyList() else {
            val type = object : TypeToken<List<Product>>() {}.type
            gson.fromJson(json, type)
        }
    }
}

@Composable
fun AppPrincipal() {
    val context = LocalContext.current
    var tela by remember { mutableStateOf("login") }
    
    // Banco de usuários sincronizado
    val usuarios = remember { 
        mutableStateMapOf<String, User>().apply { putAll(Database.loadUsers(context)) }
    }
    
    // Lista de produtos específica do usuário logado
    val produtos = remember { mutableStateListOf<Product>() }
    
    var emailUsuarioLogado by remember { mutableStateOf("") }
    var nomeUsuarioLogado by remember { mutableStateOf("") }

    Surface(modifier = Modifier.fillMaxSize()) {
        Crossfade(targetState = tela, label = "") { telaAtual ->
            when (telaAtual) {
                "login" -> TelaLogin(
                    usuarios = usuarios,
                    aoLogar = { user ->
                        emailUsuarioLogado = user.email
                        nomeUsuarioLogado = user.name
                        produtos.clear()
                        produtos.addAll(Database.loadProducts(context, user.email))
                        tela = "home"
                    },
                    aoIrParaCadastro = { tela = "cadastro" }
                )
                "cadastro" -> TelaCadastro(
                    aoCadastrar = { nome, email, senha ->
                        val chave = email.trim().lowercase()
                        usuarios[chave] = User(nome, chave, senha)
                        Database.saveUsers(context, usuarios)
                        tela = "login"
                    },
                    aoVoltar = { tela = "login" }
                )
                "home" -> TelaDashboard(
                    nomeUsuario = nomeUsuarioLogado,
                    listaProdutos = produtos,
                    aoSair = { tela = "login" },
                    aoSalvarProduto = { 
                        Database.saveProducts(context, emailUsuarioLogado, produtos) 
                    }
                )
            }
        }
    }
}

@Composable
fun TelaLogin(usuarios: Map<String, User>, aoLogar: (User) -> Unit, aoIrParaCadastro: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var senha by remember { mutableStateOf("") }
    var erro by remember { mutableStateOf("") }

    val realizarLogin = {
        val u = usuarios[email.trim().lowercase()]
        if (u != null && u.pass == senha) {
            aoLogar(u)
        } else {
            erro = "E-mail ou senha incorretos!"
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFFFFEBF2)), contentAlignment = Alignment.Center) {
        Card(
            modifier = Modifier.padding(20.dp).widthIn(max = 500.dp).fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.chatgpt_image_30_de_set__de_2026__20_03_50),
                        contentDescription = "Logo",
                        modifier = Modifier.size(60.dp).clip(RoundedCornerShape(12.dp))
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Fsystem", style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black, color = Color(0xFFFF4B81)))
                }
                
                Text("Gerencie seus produtos com facilidade", fontSize = 14.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(30.dp))
                
                if (erro != "") Text(erro, color = Color.Red, fontSize = 14.sp, modifier = Modifier.padding(bottom = 12.dp))

                InputFsystem("E-MAIL", email, Icons.Default.Email, "seu@email.com") { email = it; erro = "" }
                Spacer(modifier = Modifier.height(10.dp))
                InputFsystem("SENHA", senha, Icons.Default.Lock, "••••", isPass = true, onDone = realizarLogin) { senha = it; erro = "" }

                Spacer(modifier = Modifier.height(30.dp))
                
                Button(
                    onClick = realizarLogin,
                    modifier = Modifier.fillMaxWidth().height(55.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4B81)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("ENTRAR NO SISTEMA", fontWeight = FontWeight.Bold)
                }
                
                TextButton(onClick = aoIrParaCadastro) {
                    Text("Criar nova conta no Fsystem", color = Color.Gray)
                }
            }
        }
    }
}

@Composable
fun TelaCadastro(aoCadastrar: (String, String, String) -> Unit, aoVoltar: () -> Unit) {
    var nome by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var senha by remember { mutableStateOf("") }
    var erro by remember { mutableStateOf("") }

    val realizarCadastro = {
        if (nome.isBlank() || email.isBlank() || senha.isBlank()) {
            erro = "Preencha todos os campos!"
        } else if (!email.contains("@")) {
            erro = "O e-mail deve conter '@'!"
        } else {
            aoCadastrar(nome, email, senha)
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFFFFEBF2)), contentAlignment = Alignment.Center) {
        Card(modifier = Modifier.padding(20.dp).widthIn(max = 500.dp).fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(modifier = Modifier.padding(35.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Novo Cadastro", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2D2D2D))
                Spacer(modifier = Modifier.height(20.dp))
                
                if (erro != "") Text(erro, color = Color.Red, fontSize = 14.sp, modifier = Modifier.padding(bottom = 12.dp))

                InputFsystem("NOME COMPLETO", nome, Icons.Default.Person, "Digite seu nome") { nome = it }
                InputFsystem("E-MAIL", email, Icons.Default.Email, "ex: maria@gmail.com") { email = it }
                InputFsystem("SENHA", senha, Icons.Default.Lock, "Crie uma senha", isPass = true, onDone = realizarCadastro) { senha = it }

                Spacer(modifier = Modifier.height(30.dp))
                
                Button(
                    onClick = realizarCadastro,
                    modifier = Modifier.fillMaxWidth().height(55.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4B81)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("FINALIZAR CADASTRO", fontWeight = FontWeight.Bold)
                }
                
                TextButton(onClick = aoVoltar) {
                    Text("Já tenho conta? Voltar ao Login", color = Color.Gray)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TelaDashboard(nomeUsuario: String, listaProdutos: MutableList<Product>, aoSair: () -> Unit, aoSalvarProduto: () -> Unit) {
    var cod by remember { mutableStateOf("") }
    var mar by remember { mutableStateOf("") }
    var tip by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("") }
    var pre by remember { mutableStateOf("") }
    var cus by remember { mutableStateOf("") }
    var obs by remember { mutableStateOf("") }
    var erroForm by remember { mutableStateOf("") }

    val focusManager = LocalFocusManager.current
    val isWide = LocalConfiguration.current.screenWidthDp > 800

    val salvar = {
        if (cod==""||mar==""||tip==""||cat==""||pre==""||cus=="") {
            erroForm = "Preencha os campos obrigatórios!"
        } else {
            listaProdutos.add(Product(cod, mar, tip, cat, pre, cus, obs))
            aoSalvarProduto()
            cod=""; mar=""; tip=""; cat=""; pre=""; cus=""; obs=""; erroForm=""
            focusManager.clearFocus()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(painter = painterResource(id = R.drawable.chatgpt_image_30_de_set__de_2026__20_03_50), contentDescription = null, modifier = Modifier.size(32.dp).clip(RoundedCornerShape(6.dp)))
                        Spacer(Modifier.width(8.dp))
                        Text("Fsystem", fontWeight = FontWeight.Black, color = Color(0xFFFF4B81))
                    }
                },
                actions = {
                    IconButton(onClick = aoSair) { Icon(Icons.AutoMirrored.Filled.ExitToApp, null, tint = Color(0xFFFF4B81)) }
                }
            )
        }
    ) { p ->
        Column(modifier = Modifier.fillMaxSize().padding(p).background(Color(0xFFFFEBF2))) {
            // CABEÇALHO PROPORCIONAL - SEM LOGO
            Surface(modifier = Modifier.fillMaxWidth(), color = Color(0xFFFF4B81), shadowElevation = 4.dp) {
                Text(
                    text = "Bem vindo(a), $nomeUsuario!",
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 14.dp).fillMaxWidth(),
                    fontWeight = FontWeight.Black,
                    fontSize = 26.sp,
                    color = Color.White,
                    textAlign = TextAlign.End
                )
            }
            
            val contentMod = Modifier.padding(16.dp).fillMaxSize()
            
            if (isWide) {
                Row(contentMod, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Box(Modifier.weight(0.5f)) { FormCard(cod,{cod=it},mar,{mar=it},tip,{tip=it},cat,{cat=it},pre,{pre=it},cus,{cus=it},obs,{obs=it},erroForm, salvar) }
                    Box(Modifier.weight(0.5f)) { ListCard(listaProdutos) }
                }
            } else {
                LazyColumn(contentMod, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    item { FormCard(cod,{cod=it},mar,{mar=it},tip,{tip=it},cat,{cat=it},pre,{pre=it},cus,{cus=it},obs,{obs=it},erroForm, salvar) }
                    item { ListCard(listaProdutos) }
                }
            }
        }
    }
}

@Composable
fun FormCard(c:String,sc:(String)->Unit,m:String,sm:(String)->Unit,t:String,st:(String)->Unit,ca:String,sca:(String)->Unit,p:String,sp:(String)->Unit,cu:String,sku:(String)->Unit,o:String,so:(String)->Unit,e:String,onS:()->Unit) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)) {
        Column(Modifier.padding(24.dp)) {
            Text("Cadastrar Novo Produto", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            if(e!="") Text(e, color = Color.Red, fontSize = 13.sp, modifier = Modifier.padding(top=8.dp))
            Spacer(modifier = Modifier.height(16.dp))
            InputFsystem("Código*", c, Icons.Default.QrCode, "") { sc(it) }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f)) { InputFsystem("Marca*", m, Icons.Default.Store, "") { sm(it) } }
                Box(Modifier.weight(1f)) { InputFsystem("Tipo*", t, Icons.AutoMirrored.Filled.List, "") { st(it) } }
            }
            InputFsystem("Categoria*", ca, Icons.AutoMirrored.Filled.Label, "") { sca(it) }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f)) { InputFsystem("Preço*", p, Icons.Default.AttachMoney, "0.00", isNum = true) { sp(it) } }
                Box(Modifier.weight(1f)) { InputFsystem("Custo*", cu, Icons.Default.MoneyOff, "0.00", isNum = true) { sku(it) } }
            }
            InputFsystem("OBS", o, Icons.AutoMirrored.Filled.Notes, "", onDone = onS) { so(it) }
            Button(onClick = onS, modifier = Modifier.fillMaxWidth().padding(top = 20.dp).height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4B81)), shape = RoundedCornerShape(10.dp)) {
                Text("SALVAR NO FSYSTEM", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ListCard(lista: List<Product>) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
        Column(Modifier.padding(20.dp)) {
            Text("Produtos Cadastrados", fontWeight = FontWeight.Bold, color = Color.Gray)
            Spacer(modifier = Modifier.height(10.dp))
            if (lista.isEmpty()) Text("Nenhum produto cadastrado.", color = Color.LightGray)
            LazyColumn(Modifier.heightIn(max = 1000.dp)) {
                items(lista) { p ->
                    Card(modifier = Modifier.padding(vertical = 4.dp).fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF5F8))) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.code, fontWeight = FontWeight.Bold)
                                Text("${p.brand} | ${p.category}", fontSize = 12.sp, color = Color.Gray)
                            }
                            Text("R$ ${p.price}", fontWeight = FontWeight.Bold, color = Color(0xFFFF4B81))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InputFsystem(l:String, v:String, i:ImageVector, h:String, isPass:Boolean=false, isNum:Boolean=false, onDone:(()->Unit)?=null, onV:(String)->Unit) {
    val focusManager = LocalFocusManager.current
    Column(Modifier.padding(vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(i, null, Modifier.size(16.dp), tint = Color(0xFFFF4B81))
            Spacer(Modifier.width(8.dp))
            Text(l, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
        }
        TextField(
            value = v, onValueChange = { if (isNum) { if (it.all { c -> c.isDigit() || c == '.' }) onV(it) } else onV(it) },
            modifier = Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(8.dp)).onPreviewKeyEvent {
                if (it.type == KeyEventType.KeyDown && (it.key == Key.Enter || it.key == Key.NumPadEnter)) {
                    if (onDone != null) onDone() else focusManager.moveFocus(FocusDirection.Next)
                    true
                } else false
            },
            placeholder = { Text(h, fontSize = 14.sp, color = Color.LightGray) },
            visualTransformation = if (isPass) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = if (isNum) KeyboardType.Number else KeyboardType.Text, imeAction = if (onDone != null) ImeAction.Done else ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Next) }, onDone = { onDone?.invoke(); focusManager.clearFocus() }),
            colors = TextFieldDefaults.colors(focusedContainerColor = Color.White, unfocusedContainerColor = Color.White, focusedIndicatorColor = Color(0xFFFF4B81), unfocusedIndicatorColor = Color.Transparent),
            singleLine = true
        )
    }
}
